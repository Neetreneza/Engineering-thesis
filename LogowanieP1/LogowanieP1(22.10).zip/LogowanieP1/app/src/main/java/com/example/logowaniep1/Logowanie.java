package com.example.logowaniep1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.room.Room;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Logowanie extends AppCompatActivity {

    EditText email, haslo;
    Button loguj;
    boolean isSuccess=false;

    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logowanie);

        email = (EditText) findViewById(R.id.emailET);
        haslo = (EditText) findViewById(R.id.hasloET);
        loguj = (Button) findViewById(R.id.logowanieB);



        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        progressDialog = new ProgressDialog(this);

        loguj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doLogowanie dologowanie = new doLogowanie();
                dologowanie.execute();



            }
        });

    }

    private class doLogowanie extends AsyncTask<String,String,String>{


        String emailstr= email.getText().toString();
        String passstr= haslo.getText().toString();
        String z="";



        String em = "q";
        String password = "w";



        @Override
        protected void onPreExecute() {


            progressDialog.setMessage("Przetwarzanie...");
            progressDialog.show();


            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            if (emailstr.trim().equals("") || passstr.trim().equals(""))
                z = "Proszę uzupełnić wszystke pola";
            else {
                try {

                    Class.forName("com.mysql.jdbc.Driver");

                    Connection connection = DriverManager.getConnection("jdbc:mysql://192.168.1.102:3306/aplikacja", "andro", "andro");

                    Statement statement = connection.createStatement();

                    ResultSet resultSet = statement.executeQuery("SELECT email,haslo FROM uzytkownik");
                    while (resultSet.next()) {
                        //Log.i("email", "MOJ EMAIL: " + emailRT + " :: " + resultSet.getString(1));
                        if (emailstr.equals(resultSet.getString(1)) && passstr.equals(resultSet.getString(2)))  {
                            isSuccess = true;
                           z = "Logowanie udane";
                        }
                        else
                            z = "Niepoprawny emial lub hasło";
                    }
                }

                catch (Exception e) {
                    System.err.println("Błąd: ");
                    System.err.println(e.getMessage());
                }



            }
            return z;
        }

        @Override
        protected void onPostExecute(String s) {
            Toast.makeText(getBaseContext(),""+z, Toast.LENGTH_LONG).show();

            progressDialog.hide();
            if(isSuccess) {

            Log.i("Baza","Wynik to "+z);
            Intent resultIntent = new Intent();

                resultIntent.putExtra("result", isSuccess);

                setResult(RESULT_OK, resultIntent);
                finish();

            }
        }
    }

}
